<?php
	define('ADMIN',1);
	define('VISITEUR',2);

	define('ERR_IS_CO','You cannot access to this page if you are not connected');
	
	define('MSG_CO','<strong>Welcome ! You are connected ! </strong>');
	
	define('MSG_CO_empty','<strong>WARNING : You must fill in all the fields !</strong>');
	
	define('MSG_CO_ERR','<strong>An error has occured during your registration. The password or the e-mail adress are incorrect ! </strong>');
	
	define('MSG_DECO','<strong>You are now offline !</strong>');
?>
