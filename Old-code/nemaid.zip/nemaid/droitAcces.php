<?php
	define('ADMIN',1);
	define('VISITEUR',2);
?>
